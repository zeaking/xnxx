### INSTALLER

```
apt update && apt upgrade -y && apt install -y wget screen && wget -q https://raw.githubusercontent.com/syfqsamvpn/multiport/main/setup.sh && chmod +x setup.sh && screen -S setup ./setup.sh
```
